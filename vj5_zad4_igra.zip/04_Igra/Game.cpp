#include <iostream>
#include "Game.h"

Game::Game(const std::string& title, const std::string& player_name)
    // Redoslijed inicijalizacije prati redoslijed deklaracije članova u Game.h.
    // level mora nastati prije playera jer Player dobiva adresu tog levela.
    : title(title), level(), player(player_name, &level) {
}

void Game::print() const {
    std::cout << title << '\n';
    player.print();
}
