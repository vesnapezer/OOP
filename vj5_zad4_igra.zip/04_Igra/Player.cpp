#include <iostream>
#include "Player.h"

Player::Player(const std::string& name, Level* level)
    : name(name), current_level(level) {
}

void Player::print() const {
    std::cout << "Igrac: " << name << '\n';

    if (current_level != nullptr) {
        std::cout << "Level: neprijatelja "
                  << current_level->enemy_count()
                  << ", oruzja "
                  << current_level->weapon_count() << '\n';
    }
}
