#pragma once
#include <string>

class Weapon {
private:
    std::string name;

public:
    explicit Weapon(const std::string& name);
};
