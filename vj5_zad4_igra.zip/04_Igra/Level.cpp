#include "Level.h"

Level::Level()
    : enemies{Enemy("Goblin")}, weapons{} {
    // Level mora imati barem jednog neprijatelja
}

int Level::enemy_count() const {
    return static_cast<int>(enemies.size());
}

int Level::weapon_count() const {
    return static_cast<int>(weapons.size());
}
