#pragma once
#include <string>

class Enemy {
private:
    std::string name;

public:
    explicit Enemy(const std::string& name);
};
