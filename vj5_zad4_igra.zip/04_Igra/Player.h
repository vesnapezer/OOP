#pragma once
#include <string>
#include "Level.h"

class Player {
private:
    std::string name;
    Level* current_level;  // Asocijacija: Player poznaje Level, ali ga ne posjeduje.

public:
    Player(const std::string& name, Level* level);
    void print() const;
};
