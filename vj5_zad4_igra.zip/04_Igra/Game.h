#pragma once
#include <string>
#include "Level.h"
#include "Player.h"

class Game {
private:
    std::string title;
    Level level;   // Game ima svoj Level
    Player player; // Game ima svog Playera

public:
    Game(const std::string& title, const std::string& player_name);
    void print() const;
};
